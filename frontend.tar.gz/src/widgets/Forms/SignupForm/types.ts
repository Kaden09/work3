export interface ISignupForm {
  email: string;
  password: string;
  repeatPassword: string;
}
