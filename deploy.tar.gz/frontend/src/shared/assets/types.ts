export interface IIcon {
  width: number;
  height: number;
  className?: string;
}
