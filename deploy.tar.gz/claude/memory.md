# Memory - Work 500 Project

## Общая информация
- **Название**: Work 500 (MessagingPlatform)
- **Тип**: Платформа для управления аккаунтами маркетплейсов и мессенджинга
- **Основной стек**: .NET 9 (Backend) + React 19 + TypeScript (Frontend)
- **Архитектура**: Clean Architecture (Domain, Application, Infrastructure, API)

## Сервер и деплой
- **IP**: 91.207.183.204
- **User**: root
- **SSH ключ**: ~/.ssh/id_ed25519
- **SSH alias**: `work-server` (в ~/.ssh/config)
- **Uptime**: 23+ дней
- **Расположение проекта**: `/root/app/`
- **Деплой**: GitHub Actions → Docker build на сервере → docker-compose up

### Деплой процесс
1. Push в main → GitHub Actions срабатывает
2. Копирует файлы на сервер в /tmp/work500-build
3. Билдит образы: app-api:latest, app-frontend:latest
4. Запускает docker-compose.prod.yml из /root/app/
5. Чистит /tmp/work500-build

### Docker контейнеры (на сервере)
- app-frontend (nginx:alpine) - порт 80
- app-api (.NET 9) - порт 8080
- app-postgres (postgres:17-alpine)
- app-redis (redis:7-alpine)

## Backend архитектура

### Слои (Clean Architecture)
```
src/
├── Domain/           # Entities, ValueObjects, Enums, Exceptions
├── Application/      # Commands, Queries, DTOs, Interfaces
├── Infrastructure/   # EF Core, Repositories, External APIs
└── API/             # Minimal APIs, Endpoints, Middleware
```

### Entities (Domain layer)
1. **User** - пользователи системы
   - Email (ValueObject)
   - PasswordHash (ValueObject)
   - Role (Admin/User)
   - Theme (Dark/Light)
   - Failed login attempts + lockout механизм (5 попыток → 15 мин блокировка)

2. **RefreshToken** - refresh токены для JWT
   - Token (ValueObject)
   - UserId
   - ExpiresAt, IsRevoked, IsUsed

3. **WbAccount** - аккаунты Wildberries
   - UserId
   - ApiToken (ValueObject)
   - ShopName
   - Status (Active/Inactive/TokenExpired/Error)
   - LastSyncAt, TokenExpiresAt
   - ErrorMessage

4. **WbOrder** - заказы из Wildberries
   - WbAccountId
   - WbOrderId (long)
   - Status (New/Cancelled)
   - CustomerPhone, TotalPrice, Currency
   - ProductName, Quantity
   - WbCreatedAt

5. **Chat** - чаты (заглушка для будущего функционала)
   - UserId
   - ContactName, ContactAvatar
   - LastMessageText, LastMessageAt
   - UnreadCount

### Key Features
- **Auth**: JWT + Refresh tokens в HttpOnly cookies
- **Security**:
  - BCrypt для паролей
  - Rate limiting (auth: 10/мин, api: 100/мин)
  - Account lockout после 5 неверных попыток
  - Cookie Secure флаг адаптируется к протоколу (HTTP/HTTPS)
- **Wildberries API**:
  - Интеграция с marketplace-api.wildberries.ru
  - Синхронизация заказов
  - Валидация токенов
  - JWT expiration parsing для WB токенов

### API Endpoints

#### Auth
```
POST   /api/Auth/register
POST   /api/Auth/login
POST   /api/Auth/logout
POST   /api/Auth/refresh
GET    /api/Auth/me
```

#### Wildberries
```
POST   /api/Wildberries/accounts          # Добавить аккаунт
GET    /api/Wildberries/accounts          # Список аккаунтов
DELETE /api/Wildberries/accounts/{id}     # Удалить аккаунт
PUT    /api/Wildberries/accounts/{id}/token # Обновить токен
POST   /api/Wildberries/accounts/{id}/sync  # Синхронизация заказов
GET    /api/Wildberries/accounts/{id}/orders # Список заказов
```

#### User
```
PUT    /api/User/theme
```

#### Chats (заглушка)
```
GET    /api/Chats
```

### Middleware
1. **ExceptionMiddleware** - глобальная обработка ошибок
2. **CookieAuthMiddleware** - извлечение JWT из cookies и установка в заголовок

### Infrastructure
- **EF Core 9** с миграциями
- **PostgreSQL 17**
- **Redis 7** (пока не используется активно)
- **MediatR** для CQRS паттерна
- **FluentValidation**

### External Services
- **WildberriesApiClient**: HTTP клиент для Wildberries API
  - Пагинация через next параметр
  - Парсинг JWT токенов для определения expiration
  - Обработка ошибок (401, 403, 429, 500, 502, 503)

## Frontend архитектура

### Структура
```
frontend/src/
├── app/              # Роутинг
├── pages/            # Страницы (Landing, Auth, Home)
│   ├── Auth/         # Login, Signup, Recovery, Verify
│   ├── Home/         # App, Accounts, Chats, Profile, Transactions
│   ├── Landing/
│   └── Others/       # Error, NotFound, Offer, Privacy
├── shared/
│   ├── api/          # axios конфиг, hooks, requests
│   ├── components/
│   ├── config/
│   ├── context/      # AuthContext, ThemeContext
│   ├── hooks/
│   ├── store/        # Zustand
│   ├── ui/           # UI компоненты
│   └── utils/
└── widgets/          # Сложные компоненты (Forms, Sidebar, etc)
```

### Стек Frontend
- React 19
- TypeScript
- Vite 7
- React Router v7
- TanStack Query v5
- Axios
- React Hook Form + Yup
- Zustand (state management)
- Tailwind CSS v4
- Lucide React (иконки)

### Key Features
- **Auth**:
  - AuthContext с react-query
  - Проверка сессии при navigation (popstate event)
  - staleTime: 0 для постоянной валидации
  - Logout с полной очисткой (queryClient.clear(), localStorage, sessionStorage)
- **Адаптивная верстка**: mobile-first, брейкпоинты 320, 640, 768, 1024
- **ErrorBoundary**: централизованная обработка ошибок через роутер
- **Private routes**: защита через PrivateRoute компонент

### API интеграция
- Base URL: `/api` (nginx проксирует на бэкенд)
- Cookies автоматически отправляются (credentials: 'include')
- Все ответы в формате: `{ success: bool, data?: T, error?: string }`

## База данных

### Таблицы
1. **users** - пользователи
2. **refresh_tokens** - refresh токены
3. **wb_accounts** - аккаунты Wildberries
4. **wb_orders** - заказы Wildberries
5. **chats** - чаты (пока не используется)

### Миграции
Все миграции в `src/Infrastructure/Persistence/Migrations/`
Автоматически применяются при старте API (Program.cs:58)

## Конфигурация

### Environment Variables (Production)
```env
ASPNETCORE_ENVIRONMENT=Production
ConnectionStrings__Database=Host=postgres;Database=app_db;Username=app_user;Password=***
Jwt__Secret=***
Jwt__Issuer=MessagingPlatform
Jwt__Audience=MessagingPlatform
Jwt__AccessTokenExpirationMinutes=15
Jwt__RefreshTokenExpirationDays=7
```

### GitHub Secrets
- SERVER_HOST (91.207.183.204)
- SERVER_USER (root)
- SERVER_SSH_KEY (содержимое id_ed25519)
- CR_PAT (для ghcr.io, но пока не используется - билдим локально на сервере)

## Стиль кода

### Правила (из CLAUDE.md)
- Избегать детекции AI: разный стиль в разных файлах
- Без идеального форматирования
- Местами camelCase, местами подчеркивание для приватных
- Разная длина строк
- Можно сленг в именах переменных
- Разный порядок модификаторов

### Clean Architecture
- Без монолита, все по слоям
- Без лишних комментариев
- Senior-level код
- Никаких следов AI

## Что дальше (из REPORT.md)
- [ ] HTTPS через Let's Encrypt
- [ ] Подключить внешние API (Avito и тд)
- [ ] WebSocket для real-time чатов
- [ ] Мультиаккаунты
- [ ] SMS интеграция

## Исправленные проблемы
1. **Cookie Security** - адаптивный Secure флаг для HTTP/HTTPS
2. **Logout** - полная очистка сессии и защита от back button
3. **Error Boundary** - централизованная обработка ошибок
4. **Mobile responsive** - адаптивная верстка для всех устройств
5. **Token expiry tracking** - отслеживание истечения WB токенов

## Текущее состояние
- Backend: полностью рабочий, все endpoints реализованы
- Frontend: интеграция с бэкендом завершена, адаптивная верстка готова
- Деплой: автоматический через GitHub Actions
- Сервер: стабильно работает 23+ дня
- БД: PostgreSQL с миграциями, данные персистентные

## Технические детали
- .NET 9 Minimal APIs
- EF Core 9 с миграциями
- JWT в HttpOnly cookies (XSS protection)
- BCrypt для паролей
- Rate limiting по IP
- Docker multi-stage builds
- Nginx reverse proxy
- Volumes для PostgreSQL и Redis
